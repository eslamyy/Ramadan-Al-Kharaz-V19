package com.ramadanalkharaz.center;

import android.app.Activity;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.content.Context;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;
import android.widget.Toast;
import android.os.ParcelFileDescriptor;
import android.os.CancellationSignal;
import android.print.PageRange;
import android.print.PrintDocumentInfo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int REQUEST_SAVE_BACKUP = 703;
    private static final int REQUEST_RESTORE_BACKUP = 704;
    private ValueCallback<Uri[]> pendingFileChooser;
    private String pendingBackupContent;
    private String pendingBackupName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setDefaultTextEncodingName("UTF-8");

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view,
                    ValueCallback<Uri[]> filePathCallback,
                    FileChooserParams fileChooserParams) {
                if (pendingFileChooser != null) {
                    pendingFileChooser.onReceiveValue(null);
                    pendingFileChooser = null;
                }
                pendingFileChooser = filePathCallback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES,
                    new String[]{"application/json", "text/json", "application/octet-stream"});
                try {
                    startActivityForResult(intent, REQUEST_RESTORE_BACKUP);
                    return true;
                } catch (ActivityNotFoundException e) {
                    pendingFileChooser.onReceiveValue(null);
                    pendingFileChooser = null;
                    Toast.makeText(MainActivity.this,
                        "تعذر فتح نافذة اختيار ملف النسخة الاحتياطية",
                        Toast.LENGTH_LONG).show();
                    return false;
                }
            }
        });
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidPrint");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private PrintAttributes.MediaSize getMediaSize(String paper) {
        if ("A5".equalsIgnoreCase(paper)) return PrintAttributes.MediaSize.ISO_A5;
        if ("LETTER".equalsIgnoreCase(paper)) return PrintAttributes.MediaSize.NA_LETTER;
        if ("LEGAL".equalsIgnoreCase(paper)) return PrintAttributes.MediaSize.NA_LEGAL;
        return PrintAttributes.MediaSize.ISO_A4;
    }

    private PrintAttributes getPrintAttributes(String paper) {
        return new PrintAttributes.Builder()
            .setMediaSize(getMediaSize(paper))
            .setResolution(new PrintAttributes.Resolution("invoice", "invoice", 300, 300))
            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
            .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
            .build();
    }

    private int[] getPdfPagePoints(String paper) {
        if ("A5".equalsIgnoreCase(paper)) return new int[]{420, 595};
        if ("LETTER".equalsIgnoreCase(paper)) return new int[]{612, 792};
        if ("LEGAL".equalsIgnoreCase(paper)) return new int[]{612, 1008};
        return new int[]{595, 842};
    }

    private String safeFileName(String name) {
        String n = name == null ? "" : name.trim();
        if (n.length() == 0) n = "فاتورة_مركز_رمضان_الخراز";
        n = n.replaceAll("[\\\\/:*?\"<>|\\n\\r]+", "_");
        if (!n.toLowerCase().endsWith(".pdf")) n += ".pdf";
        return n;
    }

    private void sharePdf(File pdfFile, String fileName, boolean whatsappOnly) {
        Uri uri = Uri.parse(
            "content://" + getPackageName() +
            ".invoiceprovider/" + Uri.encode(fileName)
        );

        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("application/pdf");
        send.putExtra(Intent.EXTRA_STREAM, uri);
        send.putExtra(Intent.EXTRA_SUBJECT, fileName);
        send.putExtra(Intent.EXTRA_TEXT, "فاتورة من مركز رمضان الخراز");
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        if (!whatsappOnly) {
            startActivity(Intent.createChooser(send, "مشاركة الفاتورة PDF"));
            return;
        }

        // Try normal WhatsApp first, then WhatsApp Business.
        try {
            Intent wa = new Intent(send);
            wa.setPackage("com.whatsapp");
            startActivity(wa);
        } catch (ActivityNotFoundException first) {
            try {
                Intent wab = new Intent(send);
                wab.setPackage("com.whatsapp.w4b");
                startActivity(wab);
            } catch (ActivityNotFoundException second) {
                Toast.makeText(
                    MainActivity.this,
                    "واتساب غير مثبت. سيتم فتح قائمة المشاركة.",
                    Toast.LENGTH_SHORT
                ).show();
                startActivity(Intent.createChooser(send, "مشاركة الفاتورة PDF"));
            }
        }
    }

    // V19.2.1: Use the public Android printing API. The former direct
    // PrintDocumentAdapter callbacks are package-private and cannot compile.
    // The system print UI can save the invoice as PDF or send it to a printer.
    private void createAndSharePdf(final String requestedName, final boolean whatsappOnly, final String paper) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                Toast.makeText(MainActivity.this,
                    "اختر حفظ كملف PDF من نافذة الطباعة، ثم شارك الملف من هاتفك",
                    Toast.LENGTH_LONG).show();
                PrintManager manager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter(safeFileName(requestedName));
                manager.print(safeFileName(requestedName), adapter, getPrintAttributes("A4"));
            }
        });
    }

    private class AndroidBridge {
        @JavascriptInterface
        public void printInvoice(final String paper) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    PrintManager pm =
                        (PrintManager) getSystemService(Context.PRINT_SERVICE);

                    PrintDocumentAdapter adapter =
                        webView.createPrintDocumentAdapter("فاتورة مركز رمضان الخراز");

                    pm.print(
                        "فاتورة مركز رمضان الخراز",
                        adapter,
                        getPrintAttributes("A4")
                    );
                }
            });
        }

        @JavascriptInterface
        public void shareInvoicePdf(String fileName, String paper) {
            createAndSharePdf(fileName, false, paper);
        }

        @JavascriptInterface
        public void shareInvoicePdfToWhatsApp(String fileName, String paper) {
            createAndSharePdf(fileName, true, paper);
        }

        @JavascriptInterface
        public String loadUsers() {
            File file = new File(getFilesDir(), "users.json");
            if (!file.exists()) return "";
            try (FileInputStream in = new FileInputStream(file)) {
                byte[] data = new byte[(int) file.length()];
                int count = in.read(data);
                return count <= 0 ? "" : new String(data, 0, count, StandardCharsets.UTF_8);
            } catch (Exception e) { return ""; }
        }

        @JavascriptInterface
        public boolean saveUsers(String json) {
            if (json == null || json.length() > 2_000_000) return false;
            File target = new File(getFilesDir(), "users.json");
            File temp = new File(getFilesDir(), "users.json.tmp");
            try (FileOutputStream out = new FileOutputStream(temp)) {
                out.write(json.getBytes(StandardCharsets.UTF_8));
                out.flush();
            } catch (Exception e) { return false; }
            if (target.exists() && !target.delete()) return false;
            return temp.renameTo(target);
        }

        @JavascriptInterface
        public void saveBackupFile(final String fileName, final String content) {
            if (content == null || content.length() > 20_000_000) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                    "تعذر حفظ النسخة الاحتياطية: حجم الملف غير صالح", Toast.LENGTH_LONG).show());
                return;
            }
            pendingBackupContent = content;
            pendingBackupName = safeBackupName(fileName);
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, pendingBackupName);
                try {
                    startActivityForResult(intent, REQUEST_SAVE_BACKUP);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this,
                        "تعذر فتح نافذة حفظ النسخة الاحتياطية", Toast.LENGTH_LONG).show();
                    pendingBackupContent = null;
                    pendingBackupName = null;
                }
            });
        }
    }

    private String safeBackupName(String name) {
        String n = name == null ? "Ramadan_Al_Kharaz_Backup.json" : name;
        n = n.replaceAll("[\\/:*?\"<>|\n\r]+", "_");
        if (!n.toLowerCase().endsWith(".json")) n += ".json";
        return n;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_RESTORE_BACKUP) {
            if (pendingFileChooser != null) {
                Uri[] result = null;
                if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                    result = new Uri[]{data.getData()};
                }
                pendingFileChooser.onReceiveValue(result);
                pendingFileChooser = null;
            }
            return;
        }

        if (requestCode != REQUEST_SAVE_BACKUP) return;
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            pendingBackupContent = null;
            pendingBackupName = null;
            Toast.makeText(this, "تم إلغاء حفظ النسخة الاحتياطية", Toast.LENGTH_SHORT).show();
            return;
        }
        try (OutputStream out = getContentResolver().openOutputStream(data.getData(), "w")) {
            if (out == null) throw new Exception("تعذر فتح الملف");
            out.write(pendingBackupContent.getBytes(StandardCharsets.UTF_8));
            out.flush();
            Toast.makeText(this, "تم حفظ النسخة الاحتياطية في المكان الذي اخترته", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "فشل حفظ النسخة الاحتياطية", Toast.LENGTH_LONG).show();
        } finally {
            pendingBackupContent = null;
            pendingBackupName = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
