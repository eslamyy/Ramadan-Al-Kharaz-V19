V19.2: A4 portrait layout for both print and shared PDF. Added last-in-order print CSS overrides to disable mobile transforms and fixed-width clipping. Not yet tested on Android hardware.
