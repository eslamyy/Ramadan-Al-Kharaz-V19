package com.ramadanalkharaz.center;

import android.app.Activity;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.content.Context;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;
import android.widget.Toast;
import android.os.ParcelFileDescriptor;
import android.os.CancellationSignal;
import android.print.PageRange;
import android.print.PrintDocumentInfo;

import java.io.File;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.auth.AuthCredential;
import com.google.android.libraries.identity.googleid.GetGoogleIdOption;
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;
import androidx.credentials.CredentialManager;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.Credential;
import androidx.credentials.CustomCredential;
import androidx.credentials.exceptions.GetCredentialException;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.GetCredentialResponse;
import androidx.annotation.NonNull;
import org.json.JSONObject;


public class MainActivity extends Activity {
    private WebView webView;
    private FirebaseAuth firebaseAuth;

    private void authEvent(String status, String message) {
        try {
            JSONObject payload = new JSONObject();
            payload.put("status", status);
            payload.put("message", message);
            payload.put("uid", firebaseAuth.getCurrentUser() == null ? "" : firebaseAuth.getCurrentUser().getUid());
            payload.put("email", firebaseAuth.getCurrentUser() == null ? "" : firebaseAuth.getCurrentUser().getEmail());
            final String js = "window.dispatchEvent(new CustomEvent('ramadanFirebaseAuth', {detail:" + payload.toString() + "}));";
            runOnUiThread(() -> webView.evaluateJavascript(js, null));
        } catch (Exception ignored) { }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        firebaseAuth = FirebaseAuth.getInstance();
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setDefaultTextEncodingName("UTF-8");

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidPrint");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private PrintAttributes.MediaSize getMediaSize(String paper) {
        if ("A5".equalsIgnoreCase(paper)) return PrintAttributes.MediaSize.ISO_A5;
        if ("LETTER".equalsIgnoreCase(paper)) return PrintAttributes.MediaSize.NA_LETTER;
        if ("LEGAL".equalsIgnoreCase(paper)) return PrintAttributes.MediaSize.NA_LEGAL;
        return PrintAttributes.MediaSize.ISO_A4;
    }

    private PrintAttributes getPrintAttributes(String paper) {
        return new PrintAttributes.Builder()
            .setMediaSize(getMediaSize(paper))
            .setResolution(new PrintAttributes.Resolution("invoice", "invoice", 300, 300))
            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
            .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
            .build();
    }

    private int[] getPdfPagePoints(String paper) {
        if ("A5".equalsIgnoreCase(paper)) return new int[]{420, 595};
        if ("LETTER".equalsIgnoreCase(paper)) return new int[]{612, 792};
        if ("LEGAL".equalsIgnoreCase(paper)) return new int[]{612, 1008};
        return new int[]{595, 842};
    }

    private String safeFileName(String name) {
        String n = name == null ? "" : name.trim();
        if (n.length() == 0) n = "فاتورة_مركز_رمضان_الخراز";
        n = n.replaceAll("[\\\\/:*?\"<>|\\n\\r]+", "_");
        if (!n.toLowerCase().endsWith(".pdf")) n += ".pdf";
        return n;
    }

    private void sharePdf(File pdfFile, String fileName, boolean whatsappOnly) {
        Uri uri = Uri.parse(
            "content://" + getPackageName() +
            ".invoiceprovider/" + Uri.encode(fileName)
        );

        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("application/pdf");
        send.putExtra(Intent.EXTRA_STREAM, uri);
        send.putExtra(Intent.EXTRA_SUBJECT, fileName);
        send.putExtra(Intent.EXTRA_TEXT, "فاتورة من مركز رمضان الخراز");
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        if (!whatsappOnly) {
            startActivity(Intent.createChooser(send, "مشاركة الفاتورة PDF"));
            return;
        }

        // Try normal WhatsApp first, then WhatsApp Business.
        try {
            Intent wa = new Intent(send);
            wa.setPackage("com.whatsapp");
            startActivity(wa);
        } catch (ActivityNotFoundException first) {
            try {
                Intent wab = new Intent(send);
                wab.setPackage("com.whatsapp.w4b");
                startActivity(wab);
            } catch (ActivityNotFoundException second) {
                Toast.makeText(
                    MainActivity.this,
                    "واتساب غير مثبت. سيتم فتح قائمة المشاركة.",
                    Toast.LENGTH_SHORT
                ).show();
                startActivity(Intent.createChooser(send, "مشاركة الفاتورة PDF"));
            }
        }
    }

    // V19.2.1: Use the public Android printing API. The former direct
    // PrintDocumentAdapter callbacks are package-private and cannot compile.
    // The system print UI can save the invoice as PDF or send it to a printer.
    private void createAndSharePdf(final String requestedName, final boolean whatsappOnly, final String paper) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                Toast.makeText(MainActivity.this,
                    "اختر حفظ كملف PDF من نافذة الطباعة، ثم شارك الملف من هاتفك",
                    Toast.LENGTH_LONG).show();
                PrintManager manager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter(safeFileName(requestedName));
                manager.print(safeFileName(requestedName), adapter, getPrintAttributes("A4"));
            }
        });
    }

    private class AndroidBridge {
        @JavascriptInterface
        public void signInWithEmail(String email, String password) {
            runOnUiThread(() -> firebaseAuth.signInWithEmailAndPassword(email.trim(), password)
                .addOnSuccessListener(result -> authEvent("signed_in", ""))
                .addOnFailureListener(error -> authEvent("error", "تعذر تسجيل الدخول. تحقق من البريد وكلمة المرور.")));
        }

        @JavascriptInterface
        public void signOutFirebase() {
            runOnUiThread(() -> {
                firebaseAuth.signOut();
                authEvent("signed_out", "");
            });
        }

        @JavascriptInterface
        public void getFirebaseSession() {
            authEvent(firebaseAuth.getCurrentUser() == null ? "signed_out" : "signed_in", "");
        }

        @JavascriptInterface
        public void signInWithGoogle() {
            runOnUiThread(() -> {
                GetGoogleIdOption googleOption = new GetGoogleIdOption.Builder()
                    .setFilterByAuthorizedAccounts(false)
                    .setServerClientId(getString(R.string.default_web_client_id))
                    .build();
                GetCredentialRequest request = new GetCredentialRequest.Builder()
                    .addCredentialOption(googleOption)
                    .build();
                CredentialManager.create(MainActivity.this).getCredentialAsync(
                    MainActivity.this, request, new CancellationSignal(),
                    getMainExecutor(),
                    new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                        @Override public void onResult(GetCredentialResponse response) {
                            Credential credential = response.getCredential();
                            if (credential instanceof CustomCredential &&
                                GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL.equals(((CustomCredential) credential).getType())) {
                                try {
                                    GoogleIdTokenCredential google = GoogleIdTokenCredential.createFrom(((CustomCredential) credential).getData());
                                    AuthCredential firebaseCredential = GoogleAuthProvider.getCredential(google.getIdToken(), null);
                                    firebaseAuth.signInWithCredential(firebaseCredential)
                                        .addOnSuccessListener(result -> authEvent("signed_in", ""))
                                        .addOnFailureListener(error -> authEvent("error", "تعذر تسجيل الدخول بحساب Google."));
                                } catch (Exception e) {
                                    authEvent("error", "تعذر قراءة بيانات حساب Google.");
                                }
                            } else {
                                authEvent("error", "لم يتم اختيار حساب Google صالح.");
                            }
                        }
                        @Override public void onError(@NonNull GetCredentialException error) {
                            authEvent("error", "تم إلغاء اختيار الحساب أو تعذر فتح Google.");
                        }
                    });
            });
        }
        @JavascriptInterface
        public void printInvoice(final String paper) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    PrintManager pm =
                        (PrintManager) getSystemService(Context.PRINT_SERVICE);

                    PrintDocumentAdapter adapter =
                        webView.createPrintDocumentAdapter("فاتورة مركز رمضان الخراز");

                    pm.print(
                        "فاتورة مركز رمضان الخراز",
                        adapter,
                        getPrintAttributes("A4")
                    );
                }
            });
        }

        @JavascriptInterface
        public void shareInvoicePdf(String fileName, String paper) {
            createAndSharePdf(fileName, false, paper);
        }

        @JavascriptInterface
        public void shareInvoicePdfToWhatsApp(String fileName, String paper) {
            createAndSharePdf(fileName, true, paper);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
