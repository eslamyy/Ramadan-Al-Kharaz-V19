package com.ramadanalkharaz.center;

import android.app.Activity;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.content.Context;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;
import android.widget.Toast;
import android.os.ParcelFileDescriptor;
import android.os.CancellationSignal;
import android.print.PageRange;
import android.print.PrintDocumentInfo;

import java.io.File;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setDefaultTextEncodingName("UTF-8");

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidPrint");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private PrintAttributes.MediaSize getMediaSize(String paper) {
        if ("A5".equalsIgnoreCase(paper)) return PrintAttributes.MediaSize.ISO_A5;
        if ("LETTER".equalsIgnoreCase(paper)) return PrintAttributes.MediaSize.NA_LETTER;
        if ("LEGAL".equalsIgnoreCase(paper)) return PrintAttributes.MediaSize.NA_LEGAL;
        return PrintAttributes.MediaSize.ISO_A4;
    }

    private PrintAttributes getPrintAttributes(String paper) {
        return new PrintAttributes.Builder()
            .setMediaSize(getMediaSize(paper))
            .setResolution(new PrintAttributes.Resolution("invoice", "invoice", 300, 300))
            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
            .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
            .build();
    }

    private int[] getPdfPagePoints(String paper) {
        if ("A5".equalsIgnoreCase(paper)) return new int[]{420, 595};
        if ("LETTER".equalsIgnoreCase(paper)) return new int[]{612, 792};
        if ("LEGAL".equalsIgnoreCase(paper)) return new int[]{612, 1008};
        return new int[]{595, 842};
    }

    private String safeFileName(String name) {
        String n = name == null ? "" : name.trim();
        if (n.length() == 0) n = "فاتورة_مركز_رمضان_الخراز";
        n = n.replaceAll("[\\\\/:*?\"<>|\\n\\r]+", "_");
        if (!n.toLowerCase().endsWith(".pdf")) n += ".pdf";
        return n;
    }

    private void sharePdf(File pdfFile, String fileName, boolean whatsappOnly) {
        Uri uri = Uri.parse(
            "content://" + getPackageName() +
            ".invoiceprovider/" + Uri.encode(fileName)
        );

        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("application/pdf");
        send.putExtra(Intent.EXTRA_STREAM, uri);
        send.putExtra(Intent.EXTRA_SUBJECT, fileName);
        send.putExtra(Intent.EXTRA_TEXT, "فاتورة من مركز رمضان الخراز");
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        if (!whatsappOnly) {
            startActivity(Intent.createChooser(send, "مشاركة الفاتورة PDF"));
            return;
        }

        // Try normal WhatsApp first, then WhatsApp Business.
        try {
            Intent wa = new Intent(send);
            wa.setPackage("com.whatsapp");
            startActivity(wa);
        } catch (ActivityNotFoundException first) {
            try {
                Intent wab = new Intent(send);
                wab.setPackage("com.whatsapp.w4b");
                startActivity(wab);
            } catch (ActivityNotFoundException second) {
                Toast.makeText(
                    MainActivity.this,
                    "واتساب غير مثبت. سيتم فتح قائمة المشاركة.",
                    Toast.LENGTH_SHORT
                ).show();
                startActivity(Intent.createChooser(send, "مشاركة الفاتورة PDF"));
            }
        }
    }

    // V19.2.1: Use the public Android printing API. The former direct
    // PrintDocumentAdapter callbacks are package-private and cannot compile.
    // The system print UI can save the invoice as PDF or send it to a printer.
    private void createAndSharePdf(final String requestedName, final boolean whatsappOnly, final String paper) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                Toast.makeText(MainActivity.this,
                    "اختر حفظ كملف PDF من نافذة الطباعة، ثم شارك الملف من هاتفك",
                    Toast.LENGTH_LONG).show();
                PrintManager manager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter(safeFileName(requestedName));
                manager.print(safeFileName(requestedName), adapter, getPrintAttributes("A4"));
            }
        });
    }

    private class AndroidBridge {
        @JavascriptInterface
        public void printInvoice(final String paper) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    PrintManager pm =
                        (PrintManager) getSystemService(Context.PRINT_SERVICE);

                    PrintDocumentAdapter adapter =
                        webView.createPrintDocumentAdapter("فاتورة مركز رمضان الخراز");

                    pm.print(
                        "فاتورة مركز رمضان الخراز",
                        adapter,
                        getPrintAttributes("A4")
                    );
                }
            });
        }

        @JavascriptInterface
        public void shareInvoicePdf(String fileName, String paper) {
            createAndSharePdf(fileName, false, paper);
        }

        @JavascriptInterface
        public void shareInvoicePdfToWhatsApp(String fileName, String paper) {
            createAndSharePdf(fileName, true, paper);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
